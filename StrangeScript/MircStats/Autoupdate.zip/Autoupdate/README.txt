How to use mIRCStats automatic update batch files
=================================================
Uploaded for multiple file upload by Mikko Auvinen 2.6.2002

EXTRACT ZIP FILE TO "autoupdate" SUBDIR UNDER YOUR MIRCSTATS DIRECTORY!


BRIEF INFO
==========

When you generate stats pages with mIRCStats, you might want to show those
pages to all your friends on the same channels. This can be done by uploading
stats pages to some web server where you have access rights (username and password).

mIRCStats v1.19 and newer has built-in ftp support which takes care of file uploading
in most situations, but if you want to set up a custom ftp upload method you can use 
for example these files.




Autoupdate is just a simple dos batch file (autoupd.bat) which:

* Deletes old stats file
* Runs mircstats.exe to create a new stats file
* Waits until new stats are ready
* Uploads stats to remote web server using dos ftp with ftp script file
  (for more info about ftp command line parameters, open the dos prompt and
   type "ftp -help")


There's also another batch file (autoupd2.bat) which
in addition first downloads log file from remote server.
(for non-mIRC users..)


SETUP
=====

All you need to do is:

* Change file names in the beginning of autoupd.bat 
  (right click and EDIT to open it)

* Open ftp script file(s) (ftpup.txt / ftpdown.txt) with notepad and change:
  - server name to one you are using as your web server (1. line)
  - username (2. line)
  - password (3. line)
  - remote directory of html or log(5.line)
  - local directory of html or log(6. line)

And for ftpup.txt:
  - stats files upload pattern(s) (7. line)

And for ftpdown.txt:
  (only if you need to download logs from remote logger (eggdrop bot for example)
  - log file download pattern(s) (7. line)


PATTERNS
========

mIRCStats v1.19 and newer produces multiple result files (html, css, etc...) 
you need to transfer all these to your www server.

Files are generated in single directory and filenames are normally like:
[channelname].html, [channelname]_page_2.html, [channelname].css

Because all files start with [channelname] you can upload files with a single
upload command

mput [channelname]*.*

(Replace [channelname] with the actual name (see the names of your 
mIRCStats-generated html files).


TESTING
=======

Test it at this point by running autoupd.bat
(If you are getting environmental errors check note in the end of this file..)

You can also test ftp script files by typing same lines to ftp.exe 
which you have in the script file.


* There's several ways you can run autoupd.bat automatically:
  - Windows scheduler programs (task scheduler, system agent, at(NT))
  
  - mIRC has also built-in timer which can be used..
  	
	for example to run stats every 24 hours use:
 
 	/timerstats 30 86400 /run c:\mircstats\autoupdate\autoupd.bat

  	(this can be placed to FILE/OPTIONS/PERFORM to start timer when you run mIRC)


  - Also many other scheduler programs are available.




** To close window when autoupdate is finished, create a shortcut to windows desktop
   and check "Close on exit"! Easy.  (thanks to Chuq for informing me this one!)



Known bugs: (please mail to mircstats@nic.fi it you have fixes!)



-----
If you are getting environment errors, read this:


NOTE (from http://ocean.ucc.ie/99/callanan/batch.htm):


To prevent out-of-environment errors when running batch files 
you should also have a SHELL statement in CONFIG.SYS to specify 
a larger-than-normal environment, something like: 

	shell=c:\command.com /e:1024 /p

Some computers have COMMAND.COM only in the DOS directory, 
if there is no COMMAND.COM in the root change 'c:\command.com' 
to 'c:\dos\command.com' or wherever it is. 

If a 'set comspec=c:\command.com' line is present it should 
match the path\filename given in the shell command. 
